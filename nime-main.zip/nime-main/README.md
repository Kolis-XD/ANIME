# ANIME
<img  src="https://64.media.tumblr.com/c66f1d668af14376e412ea74c3b161fe/f58012b069eb8201-e5/s250x400/4ca7aaba3df982f6e20073220a22fc392f910049.gif" width="100%" height="100%" alt="anime"/>
<p align="center">Anime Lovers | Anime downloader</p>

# install bahan
<ul><li>pkg update && pkg upgrade</li><li>pkg install git</li><li>pkg install python</li><li>git clone https://github.com/hekelpro/nime</li><li>cd nime</li><li>python nime.py</li></ul>
